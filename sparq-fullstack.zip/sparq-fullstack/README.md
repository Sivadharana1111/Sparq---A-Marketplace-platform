# Sparq — Full-Stack Marketplace Platform

A two-sided marketplace connecting clients with freelancers and local
service pros — real backend, real database, real auth. Same frontend UI
as the prototype, now wired to an actual API instead of fake in-memory data.

## Stack
- **Backend**: Node.js + Express
- **Database**: SQLite (via `better-sqlite3`) — a single file, zero setup
- **Auth**: JWT tokens + bcrypt-hashed passwords
- **Frontend**: Plain HTML/CSS/JS (no build step), served as static files
  by the same Express server

## How to run

```bash
cd backend
npm install
npm start
```

Then open **http://localhost:3000** in your browser. That's it — one
server serves both the API and the frontend, on one port.

The database (`sparq.db`) is created automatically on first run and
seeded with demo categories and freelancer profiles.

### Environment variables (optional)
Copy `.env.example` to `.env` if you want to change the port or set a
real JWT secret:
```bash
cp .env.example .env
```
In production, **always set a real `JWT_SECRET`** — the default is not safe.

## What's real now
- **Accounts** — signup/login with hashed passwords and JWT sessions.
  Data survives a page reload and a server restart.
- **Jobs** — posting a job writes a row to the database; "My Jobs"
  reads it back from the database, scoped to the logged-in user.
- **Talent search** — search, category filter, and sort all run as real
  SQL-backed queries against the `freelancer_profiles` table.
- **Freelancer profiles** — bio, skills, and reviews are read from the
  database, with a live-computed average rating from the `reviews` table.
- **Contact/hire** — sends a real row into a `messages` table linking
  the logged-in user to the freelancer.

## What's still mocked or missing (by design — this is v1)
- **Payments/escrow** — not implemented. This is the biggest remaining
  piece; would use Stripe Connect for two-sided payouts.
- **Messaging UI** — messages are stored in the database but there's no
  inbox screen to read replies yet (contacting just confirms "sent").
- **File uploads** — no portfolio images/attachments yet.
- **Password reset / email verification** — not implemented.
- **Admin/moderation tools** — none yet.

## Project structure
```
backend/
  server.js            Express app entrypoint
  db.js                SQLite connection + schema
  data/seed.js          Seeds categories + demo freelancers
  middleware/auth.js    JWT auth middleware
  routes/
    auth.js             signup / login / me
    freelancers.js       list / profile / reviews / contact
    jobs.js               create / list / update status
    categories.js         list categories
  public/
    index.html           the frontend (same UI as before)
    app-script.js         frontend logic — now calls the real API
```

## API quick reference
| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `/api/auth/signup` | – | Create an account |
| POST | `/api/auth/login` | – | Log in |
| GET | `/api/auth/me` | ✓ | Current user |
| GET | `/api/categories` | – | List categories |
| GET | `/api/freelancers?search=&category=&sort=` | – | Search talent |
| GET | `/api/freelancers/:id` | – | Profile + reviews |
| POST | `/api/freelancers/:id/reviews` | ✓ | Leave a review |
| POST | `/api/freelancers/:id/contact` | ✓ | Message a freelancer |
| GET | `/api/jobs` | ✓ | Your posted jobs |
| POST | `/api/jobs` | ✓ | Post a job |
| PATCH | `/api/jobs/:id` | ✓ | Update job status |

## Suggested next steps
1. Stripe Connect for escrow payments.
2. A real inbox/messaging UI.
3. Deploy: any Node host works (Render, Railway, Fly.io). SQLite is
   fine for a prototype/small scale; swap to Postgres for real
   production traffic.
