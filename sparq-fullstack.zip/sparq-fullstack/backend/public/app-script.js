/* ---------------- API CONFIG ---------------- */
const API = ''; // same-origin; backend serves this file too

async function api(path, opts = {}) {
  const token = localStorage.getItem('sparq_token');
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch(API + path, { ...opts, headers });
  let data = {};
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

/* ---------------- STATE ---------------- */
let categories = [];       // loaded from /api/categories
let freelancersCache = []; // loaded per-view from /api/freelancers

let state = {
  route: 'home',
  params: {},
  user: null,        // {id, name, email, role}
  jobs: [],           // loaded from /api/jobs when logged in
  talentFilters: { search: '', category: 'all', sort: 'rating' },
};

/* ---------------- STARFIELD ---------------- */
const canvas = document.getElementById('starfield');
const ctx = canvas.getContext('2d');
let stars = [];
function initStars(){
  canvas.width = window.innerWidth; canvas.height = document.documentElement.scrollHeight;
  stars = [];
  const count = Math.floor((canvas.width*canvas.height)/9000);
  for(let i=0;i<count;i++){
    stars.push({ x:Math.random()*canvas.width, y:Math.random()*canvas.height, r:Math.random()*1.3+0.2, base:Math.random()*0.6+0.2, speed:Math.random()*0.02+0.005, phase:Math.random()*Math.PI*2 });
  }
}
let t = 0;
function drawStars(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle = '#070b1a';
  ctx.fillRect(0,0,canvas.width,canvas.height);
  stars.forEach(s=>{
    const alpha = s.base + Math.sin(t*s.speed + s.phase)*0.3;
    ctx.beginPath();
    ctx.fillStyle = `rgba(200,220,255,${Math.max(0,alpha)})`;
    ctx.arc(s.x, s.y, s.r, 0, Math.PI*2);
    ctx.fill();
  });
  t++;
  requestAnimationFrame(drawStars);
}
window.addEventListener('resize', initStars);
initStars(); drawStars();
const resizeObs = new MutationObserver(()=> initStars());
resizeObs.observe(document.getElementById('app'), {childList:true, subtree:true});

/* ---------------- TOAST ---------------- */
function toast(msg){
  const el = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  el.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(()=> el.classList.remove('show'), 2800);
}

/* ---------------- NAV RENDER ---------------- */
function renderNav(){
  const cta = document.getElementById('navcta');
  if(state.user){
    cta.innerHTML = `
      <div class="user-pill"><b>${state.user.name}</b> · ${state.user.role}
        <button class="btn btn-sm btn-ghost" onclick="logout()">Log out</button>
      </div>`;
  } else {
    cta.innerHTML = `
      <button class="btn btn-ghost" onclick="navigate('login')">Log in</button>
      <button class="btn btn-solid" onclick="navigate('postjob')">Post a Job</button>`;
  }
}

/* ---------------- ROUTING ---------------- */
function navigate(route, params={}){
  state.route = route; state.params = params;
  render();
  if(params.scroll){
    setTimeout(()=>{
      const el = document.getElementById(params.scroll);
      if(el) el.scrollIntoView({behavior:'smooth'});
    }, 60);
  } else {
    window.scrollTo(0,0);
  }
}

function showLoading(){
  document.getElementById('app').innerHTML = `<div class="wrap section" style="text-align:center; padding-top:120px; color:var(--muted);">Loading…</div>`;
}

async function render(){
  renderNav();
  const app = document.getElementById('app');
  showLoading();
  try{
    if(state.route==='home') app.innerHTML = await pageHome();
    else if(state.route==='talent') app.innerHTML = await pageTalent();
    else if(state.route==='profile') app.innerHTML = await pageProfile(state.params.id);
    else if(state.route==='postjob') app.innerHTML = await pagePostJob();
    else if(state.route==='myjobs') app.innerHTML = await pageMyJobs();
    else if(state.route==='login') app.innerHTML = pageLogin();
  } catch(err){
    app.innerHTML = `<div class="wrap section" style="text-align:center; padding-top:100px;">
      <h2 style="font-size:22px; margin-bottom:12px;">Something went wrong</h2>
      <p style="color:var(--muted); margin-bottom:20px;">${err.message}</p>
      <button class="btn btn-ghost" onclick="navigate('home')">Back home</button>
    </div>`;
  }
  requestAnimationFrame(initStars);
  buildSideRail();
}

/* ---------------- SIDE RAIL (home only) ---------------- */
function buildSideRail(){
  const rail = document.getElementById('sideRail');
  if(state.route !== 'home'){ rail.innerHTML=''; return; }
  const labels = ['01 HERO','02 QUOTE','03 CATEGORIES','04 SOLID','05 TALENT','06 HOW','07 CTA'];
  rail.innerHTML = labels.map((l,i)=>`<span onclick="scrollToSection(${i})">${String(i+1).padStart(2,'0')}</span>`).join('');
}
function scrollToSection(i){
  const secs = document.querySelectorAll('.rail-target');
  if(secs[i]) secs[i].scrollIntoView({behavior:'smooth'});
}

/* ---------------- DATA LOADERS ---------------- */
async function loadCategories(){
  if(categories.length) return categories;
  const data = await api('/api/categories');
  categories = data.categories;
  return categories;
}

/* ---------------- PAGE: HOME ---------------- */
async function pageHome(){
  await loadCategories();
  const data = await api('/api/freelancers?sort=rating');
  const featured = data.freelancers.slice(0,3);
  return `
  <div class="page">
    <header class="hero rail-target">
      <div class="wrap">
        <div class="eyebrow"><b>12,406</b> matches made this week across the network</div>
        <div class="constellation-stage">
          <svg class="constellation-svg" viewBox="0 0 480 380">
            <defs>
              <linearGradient id="gradA" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stop-color="#2fe4e0"/><stop offset="100%" stop-color="#9b8cff"/>
              </linearGradient>
            </defs>
            <path class="cline" d="M85,60 L420,190" stroke="#2fe4e0"/>
            <path class="cline" d="M390,55 L350,330" stroke="#9b8cff" style="animation-delay:.4s"/>
            <path class="cline" d="M95,335 L45,210" stroke="#2fe4e0" style="animation-delay:.8s"/>
            <circle class="core-ring r1" cx="240" cy="190" r="14"/>
            <circle class="core-ring r2" cx="240" cy="190" r="14"/>
            <circle class="core-ring r3" cx="240" cy="190" r="14"/>
            <circle class="core-dot" cx="240" cy="190" r="6"/>
          </svg>
          <div class="node-chip freelancer" style="left:17.7%; top:15.8%;"><span class="dot"></span><span><span class="who">Aiko K.</span><span class="role">Product Designer</span></span></div>
          <div class="node-chip freelancer" style="left:81.3%; top:14.5%;"><span class="dot"></span><span><span class="who">Rafael M.</span><span class="role">Full-Stack Dev</span></span></div>
          <div class="node-chip client" style="left:87.5%; top:50%;"><span class="dot"></span><span><span class="who">Startup Founder</span><span class="role">Posted a job</span></span></div>
          <div class="node-chip client" style="left:72.9%; top:86.8%;"><span class="dot"></span><span><span class="who">Local Business</span><span class="role">Hiring now</span></span></div>
          <div class="node-chip freelancer" style="left:19.8%; top:88.2%;"><span class="dot"></span><span><span class="who">Priya S.</span><span class="role">Electrician</span></span></div>
          <div class="node-chip client" style="left:9.4%; top:55.3%;"><span class="dot"></span><span><span class="who">Homeowner</span><span class="role">Needs help fast</span></span></div>
        </div>
        <div class="hero-text">
          <h1>BUSINESS!<br><span class="accent">REVOLUTION</span></h1>
          <p>Sparq connects clients with vetted freelancers and local pros in minutes — not weeks. Post a job, get matched, pay safely, done.</p>
          <div class="hero-ctas">
            <button class="btn btn-solid btn-lg" onclick="navigate('postjob')">Post a Job</button>
            <button class="btn btn-ghost btn-lg" onclick="navigate('talent')">Browse Talent →</button>
          </div>
          <div class="search-bar">
            <input id="heroSearch" type="text" placeholder="Try “logo design”, “plumber near me”, “React developer”…" onkeydown="if(event.key==='Enter') heroSearchGo()" />
            <button class="btn btn-solid btn-sm" onclick="heroSearchGo()">Search</button>
          </div>
        </div>
      </div>
    </header>

    <div class="quote-block rail-target">
      <div class="wrap">
        <span class="mark">"</span>
        <h3>FIND YOUR PERFECT MATCH</h3>
        <p>A network of vetted freelancers and local pros, ranked and matched to your job — not a pile of generic bids.</p>
        <div class="trio">
          <div><h4>SCHEDULE</h4><p>Post today, hear back from qualified pros within hours, not days.</p></div>
          <div><h4>APPLICATION</h4><p>Compare ranked profiles with verified ratings and real response times.</p></div>
          <div><h4>BUSINESS</h4><p>Escrow-protected payments mean nobody works — or pays — on blind trust.</p></div>
        </div>
      </div>
    </div>

    <div class="section rail-target" id="categories">
      <div class="wrap">
        <div class="section-head">
          <div><span class="section-eyebrow">BROWSE BY CATEGORY</span><h2>Whatever the job, someone here does it well</h2></div>
        </div>
        <div class="cat-grid">
          ${categories.map(c=>`
            <div class="cat" onclick="navigate('talent',{category:'${c.id}'})">
              <div style="font-size:22px;">${c.icon}</div>
              <h4>${c.name}</h4>
              <span>${c.count.toLocaleString()} pros</span>
            </div>`).join('')}
        </div>
      </div>
    </div>

    <div class="wrap rail-target">
      <div class="icon-row">
        <div><div class="icon-hex">${hexIcon()}</div><h5>VERIFIED IDENTITY</h5><div class="icon-underline"></div></div>
        <div><div class="icon-hex">${starIcon()}</div><h5>ESCROW PAYMENTS</h5><div class="icon-underline"></div></div>
        <div><div class="icon-hex">${diamondIcon()}</div><h5>RATED & REVIEWED</h5><div class="icon-underline"></div></div>
      </div>
    </div>

    <div class="section rail-target" id="how">
      <div class="wrap">
        <div class="section-head">
          <div><span class="section-eyebrow">FEATURED TALENT</span><h2>Top-rated pros, ready this week</h2></div>
          <button class="btn btn-ghost" onclick="navigate('talent')">View all →</button>
        </div>
        <div class="talent-grid">
          ${featured.map(f=>talentCard(f)).join('')}
        </div>
      </div>
    </div>

    <div class="wrap rail-target">
      <div class="cta-banner">
        <h2>Ready to find your next hire — or your next job?</h2>
        <p>It takes about two minutes to post a job or set up a profile. No fees to join, ever.</p>
        <div class="cta-btns">
          <button class="btn btn-solid btn-lg" onclick="navigate('postjob')">Post a Job</button>
          <button class="btn btn-ghost btn-lg" onclick="navigate('login',{role:'freelancer'})">Become a Freelancer</button>
        </div>
      </div>
    </div>

    ${footer()}
  </div>`;
}
function heroSearchGo(){
  const v = document.getElementById('heroSearch').value;
  navigate('talent', {search:v});
}
function hexIcon(){ return `<svg viewBox="0 0 100 100"><polygon points="50,6 90,28 90,72 50,94 10,72 10,28"/><polygon points="50,26 74,40 74,66 50,80 26,66 26,40"/></svg>`; }
function starIcon(){ return `<svg viewBox="0 0 100 100"><polygon points="50,10 61,38 90,40 66,58 76,88 50,70 24,88 34,58 10,40 39,38"/></svg>`; }
function diamondIcon(){ return `<svg viewBox="0 0 100 100"><polygon points="50,8 92,50 50,92 8,50"/><polygon points="50,30 70,50 50,70 30,50"/></svg>`; }

/* ---------------- PAGE: TALENT ---------------- */
async function pageTalent(){
  await loadCategories();
  if(state.params.category) state.talentFilters.category = state.params.category;
  if(state.params.search !== undefined) state.talentFilters.search = state.params.search;
  const f = state.talentFilters;

  const qs = new URLSearchParams({ search:f.search, category:f.category, sort:f.sort }).toString();
  const data = await api('/api/freelancers?' + qs);
  const list = data.freelancers;
  freelancersCache = list;

  return `
  <div class="page">
    <div class="section" style="padding-top:60px;">
      <div class="wrap">
        <div class="section-head">
          <div><span class="section-eyebrow">FIND TALENT</span><h2>Browse verified pros</h2></div>
        </div>
        <div class="filters">
          <input type="text" id="searchInput" placeholder="Search by name, role or skill…" value="${f.search}" oninput="updateTalentFilter('search', this.value)" style="min-width:240px;" />
          <select id="catSelect" onchange="updateTalentFilter('category', this.value)">
            <option value="all" ${f.category==='all'?'selected':''}>All categories</option>
            ${categories.map(c=>`<option value="${c.id}" ${f.category===c.id?'selected':''}>${c.name}</option>`).join('')}
          </select>
          <select id="sortSelect" onchange="updateTalentFilter('sort', this.value)">
            <option value="rating" ${f.sort==='rating'?'selected':''}>Top rated</option>
            <option value="rate-low" ${f.sort==='rate-low'?'selected':''}>Rate: low to high</option>
            <option value="rate-high" ${f.sort==='rate-high'?'selected':''}>Rate: high to low</option>
          </select>
          <span class="result-count">${list.length} result${list.length!==1?'s':''}</span>
        </div>
        <div class="talent-grid">
          ${list.length ? list.map(p=>talentCard(p)).join('') : `<div class="empty-state" style="grid-column:1/-1;">No pros match those filters. Try a broader search.</div>`}
        </div>
      </div>
    </div>
    ${footer()}
  </div>`;
}
let filterDebounce;
function updateTalentFilter(key, val){
  state.talentFilters[key] = val;
  clearTimeout(filterDebounce);
  filterDebounce = setTimeout(()=>{ document.getElementById('app').innerHTML = ''; pageTalent().then(html=>{ document.getElementById('app').innerHTML = html; }); }, key==='search' ? 250 : 0);
}
function talentCard(f){
  const initials = f.name.split(' ').map(n=>n[0]).join('');
  return `
  <div class="card" onclick="navigate('profile',{id:${f.id}})">
    <div class="card-top">
      <div class="avatar">${initials}</div>
      <div><div class="card-name">${f.name}</div><div class="card-role">${f.role}</div></div>
    </div>
    <div class="card-rating"><span class="stars">★★★★★</span><span style="color:var(--muted)">${f.rating.toFixed(2)} (${f.reviews})</span></div>
    <p class="bio">${f.bio}</p>
    <div class="card-foot">
      <span class="card-rate">$${f.rate}/hr</span>
      <span style="color:var(--muted); font-size:12px;">${f.online?'<span class="online-dot"></span>Online now':'Responds in a few hrs'}</span>
    </div>
  </div>`;
}

/* ---------------- PAGE: PROFILE ---------------- */
async function pageProfile(id){
  let data;
  try{ data = await api('/api/freelancers/' + id); }
  catch(err){ return `<div class="wrap section"><p>Profile not found.</p><button class="btn btn-ghost" onclick="navigate('talent')">Back to talent</button></div>`; }
  const f = data.freelancer;
  const reviews = data.reviews;
  const initials = f.name.split(' ').map(n=>n[0]).join('');
  return `
  <div class="page">
    <div class="wrap">
      <div class="profile-head">
        <div class="profile-avatar">${initials}</div>
        <div class="profile-info">
          <h1>${f.name}</h1>
          <div class="role">${f.role}</div>
          <div class="profile-meta">
            <span class="stars">★★★★★ ${f.rating.toFixed(2)}</span>
            <span>${f.reviews} reviews</span>
            <span>${f.online?'🟢 Online now':'Usually responds within a few hours'}</span>
          </div>
        </div>
      </div>
      <div class="profile-body">
        <div>
          <h3>ABOUT</h3>
          <p>${f.bio} Every engagement runs through Sparq's escrow system, so payment is only released once you approve the delivered work.</p>
          <h3>SKILLS</h3>
          <p>${f.skills.map(s=>`<span class="card-tag" style="border:1px solid var(--line); padding:5px 12px; border-radius:999px; margin-right:8px; display:inline-block; font-size:12px; margin-bottom:8px;">${s}</span>`).join('')}</p>
          <h3>REVIEWS</h3>
          ${reviews.length ? reviews.map(r=>`<div class="review"><div class="rname">${r.author_name} <span style="color:var(--cyan)">★${r.rating}</span></div><div class="rtext">"${r.text}"</div></div>`).join('') : `<p style="color:var(--muted); font-size:13px;">No reviews yet.</p>`}
        </div>
        <div>
          <div class="side-card">
            <div class="rate-big">$${f.rate}/hr</div>
            <div class="rate-label">Typical project: $${(f.rate*15).toLocaleString()}–$${(f.rate*40).toLocaleString()}</div>
            <button class="btn btn-solid" style="width:100%; justify-content:center; margin-bottom:10px;" onclick="hireFlow(${f.id}, '${f.name.replace(/'/g,"")}')">Contact ${f.name.split(' ')[0]}</button>
            <button class="btn btn-ghost" style="width:100%; justify-content:center;" onclick="navigate('talent')">← Back to search</button>
          </div>
        </div>
      </div>
    </div>
    ${footer()}
  </div>`;
}
async function hireFlow(freelancerId, name){
  if(!state.user){ toast('Log in to contact ' + name); navigate('login'); return; }
  try{
    await api(`/api/freelancers/${freelancerId}/contact`, {
      method:'POST',
      body: JSON.stringify({ text: `Hi ${name}, I'm interested in working with you — I found your profile on Sparq.` })
    });
    toast(`Message sent to ${name} — they typically reply within a few hours.`);
  }catch(err){ toast(err.message); }
}

/* ---------------- PAGE: POST A JOB ---------------- */
async function pagePostJob(){
  if(!state.user){
    return `
    <div class="page">
      <div class="wrap section" style="text-align:center; padding-top:80px;">
        <span class="section-eyebrow" style="display:block;">ONE STEP LEFT</span>
        <h2 style="font-size:26px; margin:10px 0 14px;">Log in to post a job</h2>
        <p style="color:var(--muted); max-width:420px; margin:0 auto 26px;">Creating an account takes 30 seconds and lets freelancers message you back directly.</p>
        <button class="btn btn-solid btn-lg" onclick="navigate('login',{next:'postjob'})">Log in / Sign up</button>
      </div>
      ${footer()}
    </div>`;
  }
  await loadCategories();
  return `
  <div class="page">
    <div class="wrap section" style="padding-top:60px;">
      <div class="form-shell">
        <h2>Post a Job</h2>
        <p>Describe what you need — Sparq's matching engine starts scanning for fits the moment you publish.</p>
        <form id="jobForm" onsubmit="submitJob(event)">
          <div class="field"><label>Job title</label><input required id="jTitle" type="text" placeholder="e.g. Redesign our onboarding flow" /></div>
          <div class="field-row">
            <div class="field"><label>Category</label>
              <select id="jCategory" required>${categories.map(c=>`<option value="${c.id}">${c.name}</option>`).join('')}</select>
            </div>
            <div class="field"><label>Budget range</label><input required id="jBudget" type="text" placeholder="e.g. $500–$1,200" /></div>
          </div>
          <div class="field"><label>Description</label><textarea required id="jDesc" placeholder="What does the job involve? Include timeline, deliverables, and any must-haves."></textarea></div>
          <div class="form-actions">
            <button type="submit" class="btn btn-solid btn-lg">Publish Job</button>
            <button type="button" class="btn btn-ghost btn-lg" onclick="navigate('home')">Cancel</button>
          </div>
        </form>
      </div>
    </div>
    ${footer()}
  </div>`;
}
async function submitJob(e){
  e.preventDefault();
  const btn = e.target.querySelector('button[type="submit"]');
  btn.disabled = true; btn.textContent = 'Publishing…';
  try{
    await api('/api/jobs', { method:'POST', body: JSON.stringify({
      title: document.getElementById('jTitle').value,
      category: document.getElementById('jCategory').value,
      budget: document.getElementById('jBudget').value,
      description: document.getElementById('jDesc').value,
    })});
    toast('Job published — matching pros are being notified.');
    navigate('myjobs');
  }catch(err){
    toast(err.message);
    btn.disabled = false; btn.textContent = 'Publish Job';
  }
}

/* ---------------- PAGE: MY JOBS ---------------- */
async function pageMyJobs(){
  if(!state.user){
    return `
    <div class="page">
      <div class="wrap section" style="text-align:center; padding-top:80px;">
        <h2 style="font-size:26px; margin-bottom:14px;">Log in to see your jobs</h2>
        <button class="btn btn-solid btn-lg" onclick="navigate('login',{next:'myjobs'})">Log in / Sign up</button>
      </div>
      ${footer()}
    </div>`;
  }
  await loadCategories();
  const data = await api('/api/jobs');
  state.jobs = data.jobs;
  return `
  <div class="page">
    <div class="section" style="padding-top:60px;">
      <div class="wrap">
        <div class="section-head">
          <div><span class="section-eyebrow">DASHBOARD</span><h2>My Jobs</h2></div>
          <button class="btn btn-solid" onclick="navigate('postjob')">+ Post a Job</button>
        </div>
        ${state.jobs.length ? state.jobs.map(j=>`
          <div class="job-row">
            <div>
              <h4>${j.title}</h4>
              <div class="meta"><span>${categories.find(c=>c.id===j.category)?.name || j.category}</span><span>${j.budget}</span><span>Posted ${new Date(j.created_at).toLocaleDateString('en-US',{month:'short', day:'numeric'})}</span></div>
            </div>
            <span class="status-pill ${j.status==='open'?'status-open':'status-progress'}">${j.status==='open'?'Open':j.status==='in-progress'?'In Progress':j.status}</span>
          </div>`).join('') : `<div class="empty-state">No jobs posted yet.</div>`}
      </div>
    </div>
    ${footer()}
  </div>`;
}

/* ---------------- PAGE: LOGIN / SIGNUP ---------------- */
function pageLogin(){
  pickedRole = state.params.role === 'freelancer' ? 'freelancer' : 'client';
  return `
  <div class="page">
    <div class="wrap section" style="padding-top:70px;">
      <div class="form-shell">
        <h2>Welcome to Sparq</h2>
        <p>New here? This creates an account. Already registered? The same form logs you in.</p>
        <form onsubmit="submitLogin(event)">
          <div class="field"><label>Your name</label><input required id="lName" type="text" placeholder="e.g. Jordan Lee" /></div>
          <div class="field-row">
            <div class="field"><label>Email</label><input required id="lEmail" type="email" placeholder="you@example.com" /></div>
            <div class="field"><label>Password</label><input required id="lPassword" type="password" placeholder="At least 6 characters" minlength="6" /></div>
          </div>
          <div class="role-pick">
            <div class="role-opt ${pickedRole==='client'?'sel':''}" id="roleClient" onclick="pickRole('client')"><h4>I'M HIRING</h4><p>Post jobs & find talent</p></div>
            <div class="role-opt ${pickedRole==='freelancer'?'sel':''}" id="roleFreelancer" onclick="pickRole('freelancer')"><h4>I'M FREELANCING</h4><p>Find work & get paid</p></div>
          </div>
          <div class="form-actions">
            <button type="submit" class="btn btn-solid btn-lg">Continue</button>
            <button type="button" class="btn btn-ghost btn-lg" onclick="navigate('home')">Cancel</button>
          </div>
        </form>
      </div>
    </div>
    ${footer()}
  </div>`;
}
let pickedRole = 'client';
function pickRole(r){
  pickedRole = r;
  document.getElementById('roleClient').classList.toggle('sel', r==='client');
  document.getElementById('roleFreelancer').classList.toggle('sel', r==='freelancer');
}
async function submitLogin(e){
  e.preventDefault();
  const name = document.getElementById('lName').value || 'Guest';
  const email = document.getElementById('lEmail').value;
  const password = document.getElementById('lPassword').value;
  const btn = e.target.querySelector('button[type="submit"]');
  btn.disabled = true; btn.textContent = 'Please wait…';
  try{
    let data;
    try{
      data = await api('/api/auth/signup', { method:'POST', body: JSON.stringify({ name, email, password, role: pickedRole }) });
    }catch(signupErr){
      // if the account already exists, fall back to logging in with the same credentials
      data = await api('/api/auth/login', { method:'POST', body: JSON.stringify({ email, password }) });
    }
    localStorage.setItem('sparq_token', data.token);
    state.user = { ...data.user, role: data.user.role === 'client' ? 'Client' : 'Freelancer' };
    toast(`Welcome, ${data.user.name}!`);
    const next = state.params.next || 'home';
    navigate(next);
  }catch(err){
    toast(err.message);
    btn.disabled = false; btn.textContent = 'Continue';
  }
}
function logout(){
  state.user = null;
  localStorage.removeItem('sparq_token');
  toast('Logged out.');
  navigate('home');
}
function notBuilt(){ toast("This page isn't built yet — tell me if you want it added."); }

/* ---------------- FOOTER ---------------- */
function footer(){
  return `
  <footer>
    <div class="wrap">
      <div class="foot-grid">
        <div class="foot-col">
          <div class="logo" style="margin-bottom:14px;"><div class="logo-mark"></div>SPARQ</div>
          <p style="color:var(--muted); font-size:13px; line-height:1.7; max-width:260px;">The two-sided marketplace for freelance and local work, built on fast matching and safe payments.</p>
        </div>
        <div class="foot-col"><h5>Clients</h5><a onclick="navigate('postjob')">Post a job</a><a onclick="navigate('talent')">Browse talent</a><a onclick="notBuilt()">Payment protection</a></div>
        <div class="foot-col"><h5>Freelancers</h5><a onclick="navigate('login',{role:'freelancer'})">Find work</a><a onclick="notBuilt()">Build a profile</a><a onclick="notBuilt()">Get paid</a></div>
        <div class="foot-col"><h5>Company</h5><a onclick="notBuilt()">About</a><a onclick="notBuilt()">Trust & safety</a><a onclick="notBuilt()">Support</a></div>
      </div>
      <div class="foot-bottom"><span>© 2026 Sparq, Inc.</span><span>Terms · Privacy · Cookies</span></div>
    </div>
  </footer>`;
}

/* ---------------- INIT ---------------- */
async function init(){
  const token = localStorage.getItem('sparq_token');
  if(token){
    try{
      const data = await api('/api/auth/me');
      state.user = { ...data.user, role: data.user.role === 'client' ? 'Client' : 'Freelancer' };
    }catch(e){
      localStorage.removeItem('sparq_token');
    }
  }
  render();
}
init();
