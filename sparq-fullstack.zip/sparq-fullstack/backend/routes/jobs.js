const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// GET /api/jobs — jobs belonging to the logged-in client
router.get('/', requireAuth, (req, res) => {
  const rows = db.prepare(`SELECT * FROM jobs WHERE client_id = ? ORDER BY created_at DESC`).all(req.user.id);
  res.json({ jobs: rows });
});

// POST /api/jobs — create a job (any logged-in user can post; typically a client)
router.post('/', requireAuth, (req, res) => {
  const { title, category, budget, description } = req.body || {};
  if (!title || !category || !budget || !description) {
    return res.status(400).json({ error: 'title, category, budget, and description are all required.' });
  }
  const info = db.prepare(
    `INSERT INTO jobs (client_id, title, category, budget, description, status) VALUES (?,?,?,?,?, 'open')`
  ).run(req.user.id, title, category, budget, description);
  const job = db.prepare(`SELECT * FROM jobs WHERE id = ?`).get(info.lastInsertRowid);
  res.status(201).json({ job });
});

// PATCH /api/jobs/:id — update status (must own the job)
router.patch('/:id', requireAuth, (req, res) => {
  const job = db.prepare(`SELECT * FROM jobs WHERE id = ?`).get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found.' });
  if (job.client_id !== req.user.id) return res.status(403).json({ error: 'You do not own this job.' });
  const { status } = req.body || {};
  if (!['open', 'in-progress', 'completed', 'cancelled'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status.' });
  }
  db.prepare(`UPDATE jobs SET status = ? WHERE id = ?`).run(status, job.id);
  res.json({ ok: true });
});

module.exports = router;
