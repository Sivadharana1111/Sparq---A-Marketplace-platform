const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

function withStats(row) {
  const stats = db.prepare(
    `SELECT COUNT(*) AS reviews, COALESCE(AVG(rating),5) AS rating FROM reviews WHERE freelancer_id = ?`
  ).get(row.id);
  return {
    id: row.id,
    name: row.name,
    role: row.role_title,
    category: row.category,
    rate: row.rate,
    bio: row.bio,
    skills: JSON.parse(row.skills || '[]'),
    online: !!row.online,
    rating: Number(stats.rating.toFixed(2)),
    reviews: stats.reviews,
  };
}

// GET /api/freelancers?search=&category=&sort=
router.get('/', (req, res) => {
  const { search = '', category = 'all', sort = 'rating' } = req.query;
  let rows = db.prepare(`SELECT * FROM freelancer_profiles`).all();
  let list = rows.map(withStats);

  if (category && category !== 'all') list = list.filter(f => f.category === category);
  if (search) {
    const q = String(search).toLowerCase();
    list = list.filter(f =>
      f.name.toLowerCase().includes(q) ||
      f.role.toLowerCase().includes(q) ||
      f.skills.join(' ').toLowerCase().includes(q)
    );
  }
  if (sort === 'rating') list.sort((a, b) => b.rating - a.rating);
  if (sort === 'rate-low') list.sort((a, b) => a.rate - b.rate);
  if (sort === 'rate-high') list.sort((a, b) => b.rate - a.rate);

  res.json({ freelancers: list });
});

// GET /api/freelancers/:id
router.get('/:id', (req, res) => {
  const row = db.prepare(`SELECT * FROM freelancer_profiles WHERE id = ?`).get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Freelancer not found.' });
  const profile = withStats(row);
  const reviews = db.prepare(`SELECT author_name, rating, text, created_at FROM reviews WHERE freelancer_id = ? ORDER BY created_at DESC`).all(row.id);
  res.json({ freelancer: profile, reviews });
});

// POST /api/freelancers/:id/reviews  (protected)
router.post('/:id/reviews', requireAuth, (req, res) => {
  const { rating, text } = req.body || {};
  if (!rating || !text) return res.status(400).json({ error: 'rating and text are required.' });
  const freelancer = db.prepare(`SELECT id FROM freelancer_profiles WHERE id = ?`).get(req.params.id);
  if (!freelancer) return res.status(404).json({ error: 'Freelancer not found.' });
  db.prepare(`INSERT INTO reviews (freelancer_id, author_name, rating, text) VALUES (?,?,?,?)`)
    .run(freelancer.id, req.user.name, rating, text);
  res.status(201).json({ ok: true });
});

// POST /api/freelancers/:id/contact  (protected) — creates a message
router.post('/:id/contact', requireAuth, (req, res) => {
  const { text } = req.body || {};
  const freelancer = db.prepare(`SELECT id FROM freelancer_profiles WHERE id = ?`).get(req.params.id);
  if (!freelancer) return res.status(404).json({ error: 'Freelancer not found.' });
  const msg = text && text.trim() ? text.trim() : `Hi, I'm interested in working with you — I found your profile on Sparq.`;
  db.prepare(`INSERT INTO messages (from_user_id, to_freelancer_id, text) VALUES (?,?,?)`)
    .run(req.user.id, freelancer.id, msg);
  res.status(201).json({ ok: true, message: 'Message sent.' });
});

module.exports = router;
