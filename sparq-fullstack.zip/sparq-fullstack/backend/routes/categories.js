const express = require('express');
const db = require('../db');
const router = express.Router();

router.get('/', (req, res) => {
  const rows = db.prepare(`SELECT * FROM categories ORDER BY count DESC`).all();
  res.json({ categories: rows });
});

module.exports = router;
