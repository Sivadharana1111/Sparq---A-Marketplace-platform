const db = require('../db');

const categories = [
  { id: 'dev', name: 'Web & App Development', icon: '💻', count: 3204 },
  { id: 'design', name: 'Design & Branding', icon: '🎨', count: 2118 },
  { id: 'local', name: 'Home & Local Services', icon: '🔧', count: 5930 },
  { id: 'writing', name: 'Writing & Content', icon: '✍️', count: 1742 },
  { id: 'marketing', name: 'Marketing & SEO', icon: '📈', count: 1390 },
  { id: 'tutoring', name: 'Tutoring & Coaching', icon: '🎓', count: 987 },
  { id: 'media', name: 'Photo & Video', icon: '📷', count: 1205 },
  { id: 'legal', name: 'Legal & Admin', icon: '⚖️', count: 642 },
];

const freelancers = [
  { name: 'Aiko Kimura', role_title: 'Product Designer', category: 'design', rate: 85, online: 1,
    bio: "Turns rough ideas into shippable UI. Ex-Figma, 6 years freelance, specializes in fintech and marketplace apps.",
    skills: ['Figma', 'UX Research', 'Design Systems'],
    reviews: [
      { author_name: 'Client · Startup Founder', rating: 5, text: 'Delivered exactly what we needed, ahead of schedule. Communication was excellent throughout.' },
      { author_name: 'Client · Small Business Owner', rating: 5, text: 'Second time hiring — consistent quality and always responsive.' },
    ]},
  { name: 'Rafael Moura', role_title: 'Full-Stack Developer', category: 'dev', rate: 95, online: 1,
    bio: 'React + Node specialist who ships production-ready marketplaces and dashboards. Loves tight deadlines.',
    skills: ['React', 'Node.js', 'PostgreSQL'],
    reviews: [
      { author_name: 'Client · SaaS Founder', rating: 5, text: 'Rebuilt our entire dashboard in two weeks. Clean code, great communication.' },
    ]},
  { name: 'Priya Shah', role_title: 'Licensed Electrician', category: 'local', rate: 70, online: 0,
    bio: 'Residential & small commercial wiring. Same-week availability, background-checked and insured.',
    skills: ['Wiring', 'Panel Upgrades', 'Inspections'],
    reviews: [
      { author_name: 'Homeowner', rating: 5, text: 'Fixed a dangerous wiring issue same day. Highly recommend.' },
    ]},
  { name: 'Jonas Lindgren', role_title: 'Copywriter', category: 'writing', rate: 60, online: 0,
    bio: 'Direct-response copy for landing pages and email flows. Worked with 40+ D2C brands since 2019.',
    skills: ['Email Copy', 'Landing Pages', 'Brand Voice'], reviews: [] },
  { name: 'Nia Turner', role_title: 'Math Tutor, Grades 6–12', category: 'tutoring', rate: 45, online: 1,
    bio: 'Certified teacher, 9 years tutoring experience. Specializes in algebra, geometry, and test prep.',
    skills: ['Algebra', 'SAT Prep', 'Geometry'], reviews: [] },
  { name: 'Diego Castillo', role_title: 'Video Editor', category: 'media', rate: 55, online: 0,
    bio: 'Short-form and YouTube long-form editing with motion graphics. Fast turnaround, unlimited revisions.',
    skills: ['Premiere Pro', 'Motion Graphics', 'Color Grading'], reviews: [] },
  { name: 'Sofia Reyes', role_title: 'SEO Strategist', category: 'marketing', rate: 65, online: 1,
    bio: 'Technical SEO + content strategy for SaaS companies. Average client sees 40% organic growth in 6 months.',
    skills: ['Technical SEO', 'Content Strategy', 'Analytics'], reviews: [] },
  { name: 'Marcus Webb', role_title: 'Contract Attorney', category: 'legal', rate: 120, online: 0,
    bio: 'Reviews and drafts freelance & vendor contracts for small businesses. Fast 24-48hr turnaround.',
    skills: ['Contracts', 'Compliance', 'NDAs'], reviews: [] },
  { name: 'Hana Suzuki', role_title: 'Brand Designer', category: 'design', rate: 78, online: 1,
    bio: 'Full brand identity systems — logo, type, color, guidelines — for startups raising their first round.',
    skills: ['Branding', 'Illustrator', 'Typography'], reviews: [] },
];

function seed() {
  const insertCat = db.prepare(`INSERT OR REPLACE INTO categories (id, name, icon, count) VALUES (?, ?, ?, ?)`);
  const tx1 = db.transaction((rows) => { for (const c of rows) insertCat.run(c.id, c.name, c.icon, c.count); });
  tx1(categories);

  const existing = db.prepare(`SELECT COUNT(*) AS n FROM freelancer_profiles`).get();
  if (existing.n > 0) {
    console.log('Freelancers already seeded, skipping.');
  } else {
    const insertF = db.prepare(`INSERT INTO freelancer_profiles (name, role_title, category, rate, bio, skills, online) VALUES (?,?,?,?,?,?,?)`);
    const insertR = db.prepare(`INSERT INTO reviews (freelancer_id, author_name, rating, text) VALUES (?,?,?,?)`);
    const tx2 = db.transaction((rows) => {
      for (const f of rows) {
        const info = insertF.run(f.name, f.role_title, f.category, f.rate, f.bio, JSON.stringify(f.skills), f.online);
        const fid = info.lastInsertRowid;
        for (const r of f.reviews) insertR.run(fid, r.author_name, r.rating, r.text);
      }
    });
    tx2(freelancers);
    console.log(`Seeded ${freelancers.length} freelancers.`);
  }
  console.log('Seed complete.');
}

if (require.main === module) seed();
module.exports = seed;
